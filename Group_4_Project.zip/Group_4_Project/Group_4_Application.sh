#!/bin/bash
task1 () {
#Task 1 logic here

function triangular_number() {
echo $(( $1 * ($1 + 1) / 2 ))
}
read -p "Enter the start of the range: " start
read -p "Enter the end of the range: " end
total_triangular_numbers=0
multiples_of_three=0
for (( i=$start; i<=$end; i++ )); do
current_triangular=$(triangular_number $i)
if [ $current_triangular -le $end ]; then
((total_triangular_numbers++))
if [ $((current_triangular % 3)) -eq 0 ]; then
echo $current_triangular
((multiples_of_three++))
fi
else
break
fi
done
echo "Total triangular numbers in the range: $total_triangular_numbers"
echo "Multiples of 3 found: $multiples_of_three"
}
#function for Task 2
task2 (){
#Task 2 logic here
 echo "Task 2: Find Numbers as Product of Two Even Square Numbers in Succession"

  # Get the number of pairs to print
  read -p "Enter the number of pairs to print: " num_pairs

  # Initialize counter
  pairs_count=1
   # Start with the first even square number (2^2)
  current_num=2
  # Loop until the desired number of pairs is reached
  while [ $pairs_count -le $num_pairs ]; do
    # Calculate the next number as the product of two even square numbers
    sq_current_num=$((current_num * current_num))
    next_num=$((current_num + 2))
        sq_next_num=$((next_num * next_num))
        product=$((sq_current_num * sq_next_num))
    # Check if the number is even or odd
    if [ $((product % 2)) -eq 0 ]; then
      echo "$product (Even)"
    else
      echo "$product (Odd)"
    fi

    # Increment counter and update num for the next pair
    ((pairs_count++))
    ((current_num+=2))
    ((next_num+=2))
  done
}
task3(){
#Task 3 logic here
calculate_term() {
  echo $(( $1 * $3**3 + $2 * $3 ))
}

option_1() {
  read -p "Enter 'a': " a
  read -p "Enter 'b': " b
  read -p "Enter the maximum number of terms: " max_terms

  sum=0
  echo -e "\nSequence Terms:"

  for ((n = 1; n <= max_terms; n++)); do
    term=$(calculate_term $a $b $n)
    echo -n "$term "
    ((sum += term))
  done

  echo -e "\nSum of Terms: $sum"
}

option_2() {
  read -p "Enter 'a': " a
  read -p "Enter 'b': " b
  read -p "Enter term position: " position
  read -p "Enter number to check for factors: " check_number

  term=$(calculate_term $a $b $position)
echo -e "The ${position}th term is $term."

  if [ $position -ne 0 ] && [ $((check_number % term)) -eq 0 ]; then
    echo "This term is a factor of $check_number."
  else
    echo "This term is not a factor of $check_number."
  fi
}

echo "Choose an option:"
echo "1. Calculate terms and their sum"
echo "2. Check a specific term for factors"
read -p "Enter 1 or 2: " choice

if [ "$choice" -eq 1 ]; then
  option_1
elif [ "$choice" -eq 2 ]; then
  option_2
else
  echo "Invalid choice. Exiting."
  exit 1
fi
}

#Main Script
echo "Welcome to the Application"
read -p "Enter your name: " username
continue_choice= 'true' || 'false'
'true' = 1
'false' = 2
while true; do
echo "Options:"
echo "1. Triangular Numbers(Task 1)"
echo "2. Product of Square Numbers(Task 2)"
echo "3. Sequences(Task 3)"
echo "4. Exit"

read -p "Enter your choice (1, 2, 3, 4): " option

if [ "$option" -eq "1" ]; then
    task1
  elif [ "$option" -eq "2" ]; then
    task2
  elif [ "$option" -eq "3" ]; then
    task3
  elif [ "$option" -eq "4" ]; then
    echo "Exiting.."
    exit
  else
    echo "Invalid choice. Please enter 1, 2, 3, or 4."
  fi

done
